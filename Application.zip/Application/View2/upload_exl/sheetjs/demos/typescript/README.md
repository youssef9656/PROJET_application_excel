# TypeScript

This demo originally covered direct use of the `tsc` TypeScript compiler.  At
the time when the demo was first written, TypeScript 2.2 had a module system
that was incompatible with the pure JS ecosystem.  Since then, various
language improvements and compiler changes have obviated this demo.  Uses of
TypeScript are scattered throughout other demos.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
