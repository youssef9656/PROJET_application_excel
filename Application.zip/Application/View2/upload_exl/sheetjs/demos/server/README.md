# NodeJS Server Deployments

[The new demo](https://docs.sheetjs.com/docs/demos/server) has a more focused
discussion with examples for popular JS server-side frameworks.

Cloud services are covered in separate demos:

- [AWS](https://docs.sheetjs.com/docs/demos/aws)
- [Azure](https://docs.sheetjs.com/docs/demos/azure)

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
